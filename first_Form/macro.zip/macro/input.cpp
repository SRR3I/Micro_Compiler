#include <iostream>
using namespace std;
#define x 5
int main()
{
    cout << x;
}